FactoryBot.define do
  factory :list do
    
  end
end
