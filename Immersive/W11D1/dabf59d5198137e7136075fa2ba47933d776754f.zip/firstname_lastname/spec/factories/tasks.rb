FactoryBot.define do
  factory :task do
    
  end
end
