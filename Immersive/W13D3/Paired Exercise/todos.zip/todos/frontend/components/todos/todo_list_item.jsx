import React from 'react';

export default ({ todo }) => {
    return (
        <li>
            <h4>{todo.title}</h4>
        </li>
    )
}