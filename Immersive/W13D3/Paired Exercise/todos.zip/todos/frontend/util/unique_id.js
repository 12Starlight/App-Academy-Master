export default function () {
    return new Date().getTime();
}