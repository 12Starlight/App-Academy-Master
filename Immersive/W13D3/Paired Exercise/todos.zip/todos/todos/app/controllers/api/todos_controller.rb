class Api::TodosController < ApplicationController
  def show
    
  end

  def index
  end

  def create
  end

  def update
  end

  def destroy
  end
end
