# View Wireframes

## PostIndex

![index wireframe][post_index]

## PostShow

![show wireframe][post_show]

[post_index]: ./wireframes/post_index.png
[post_show]: ./wireframes/post_show.png
