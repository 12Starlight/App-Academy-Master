import React from 'react';
import { Link } from 'react-router-dom';

const PostIndexItem = props => (
  <div></div>
);

export default PostIndexItem;
