FactoryGirl.define do
  factory :post do
    
  end
end
