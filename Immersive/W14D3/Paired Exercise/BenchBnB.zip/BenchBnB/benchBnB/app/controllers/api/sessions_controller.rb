class Api::SessionsController < ApplicationController
  def destroy
    
  end
end
