import React from 'react';
import { connect } from 'react-redux';
import { requestEvent, updateEvent } from '../../actions/event_actions';
import EventForm from './event_form';


class EditEventForm extends React.Component {

  render () {
    const { event, formType, submitEvent } = this.props;
    return (
      <EventForm
        event={event}
        formType={formType}
        submitEvent={submitEvent} />
    );
  }
}
