import React from 'react';
import EventIndexItem from './event_index_item';
import { Link } from 'react-router-dom';

class EventIndex extends React.Component {

  render() {

    return (
      <div>
      
      </div>
    );
  }
}

export default EventIndex;
