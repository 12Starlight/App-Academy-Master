import { connect } from 'react-redux';
import { requestEvents, deleteEvent } from '../../actions/event_actions';
import EventIndex from './event_index';
