import React from 'react';
import { Link } from 'react-router-dom';

const EventIndexItem = ({ event, deleteEvent }) => (
  <li>

  </li>
);

export default EventIndexItem;
