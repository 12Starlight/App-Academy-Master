class KnightPathFinder
    def initialize(arr)
    end
end