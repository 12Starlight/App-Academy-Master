require_relative 'player'

class Dealer < Player
  attr_reader :bets

  def initializ(dealer)
    @dealer = dealer
    @bets = {}
    super(bankroll)
  end

  def place_bet(dealer, amt)
    # raise "does not place bets" if dealer.place_bet == amt 
  end

  def play_hand(deck)

  end

  def take_bet(player, amt)
  end

  def pay_bets
  end
end
