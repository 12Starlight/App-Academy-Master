class Player
  attr_reader :name, :bankroll
  attr_accessor :hand

  def initialize(name = "dealer")
    @name = name 
    @bankroll = 0
  end

  def pay_winnings(bet_amt)
  end

  def return_cards(deck)
  end

  def place_bet(dealer, bet_amt)
    raise "does not place bets" if dealer.place_bet == bet_amt
  end
end
