class Deck
  attr_reader :cards

  def initialize(cards = Card.all_cards.shuffle)
    
  end

  def deal(num_cards)
  
  end

  def empty?
   
  end

  def count
   
  end

  def inspect
    "#{cards.map(&:to_s)}"
  end

  def receive(new_cards)
    
  end
  
end
