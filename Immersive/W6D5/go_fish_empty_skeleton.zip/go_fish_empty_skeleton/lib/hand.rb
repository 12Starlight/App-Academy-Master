class Hand
  attr_reader :books, :cards

  def initialize()
    
  end

  def include?(value)
    
  end

  def empty?
    
  end

  def count
    
  end

  def give_up(value)
    
  end

  def receive(new_cards)
    
  end

  # This method isn't tested, but we strongly recommend you implement it as a
  # helper method. It should return a hash mapping values to the number of
  # matching cards in the hand (e.g., { king: 2, deuce: 3 })
  def count_sets

  end

  def play_books
   
  end
end
