class Player
  attr_reader :hand, :name

  def initialize(name, hand = Hand.new)
  end

  def books
  end

  def take(cards)
  end

  def give_up(value)
  end

  def has_value?(value)
  end

  def go_fish(deck)
  end

  def play_books
  end

  # returns a value and a target player
  def make_request(other_players)
  end

  def in_play?
  end

  # Don't implement these last two methods; normally we would define these
  # inside of HumanPlayer and ComputerPlayer classes.

  def choose_player(other_players)
    # DO NOT IMPLEMENT
  end

  def choose_value
    # DO NOT IMPLEMENT
  end
end
