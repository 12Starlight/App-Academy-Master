# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
StockTracker::Application.config.secret_token = '5ee33034d9a08119ad6d922dc78837e575bb4c2bb23264233f551075bbf39aeddd9572dfc084fc5ff39ae783866538bfc668cd9bf537ac25bbb7122080e70a20'
