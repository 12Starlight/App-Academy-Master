class Fan < ApplicationRecord
end
