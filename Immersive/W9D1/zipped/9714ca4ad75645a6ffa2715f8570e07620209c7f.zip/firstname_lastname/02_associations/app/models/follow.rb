class Follow < ApplicationRecord
end
