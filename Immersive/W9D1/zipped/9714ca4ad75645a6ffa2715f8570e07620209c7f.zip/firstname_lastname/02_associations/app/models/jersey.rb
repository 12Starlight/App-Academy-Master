class Jersey < ApplicationRecord
end
