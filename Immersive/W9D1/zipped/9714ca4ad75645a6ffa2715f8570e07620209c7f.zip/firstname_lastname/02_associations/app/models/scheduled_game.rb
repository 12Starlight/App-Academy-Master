class ScheduledGame < ApplicationRecord
end
