class Seat < ApplicationRecord
end
