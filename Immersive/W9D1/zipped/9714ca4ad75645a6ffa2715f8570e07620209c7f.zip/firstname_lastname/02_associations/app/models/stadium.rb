class Stadium < ApplicationRecord
end
