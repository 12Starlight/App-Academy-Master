require 'test_helper'

class CreateUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
